# - Create a variable named `numbers`
#   with the following content: `[54, 23, 66, 12]`
# - Print the sum of the second and the third element
numbers = [54,23,66,12]
print(numbers[2]+numbers[3])

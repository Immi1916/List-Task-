# - Create a variable named `numbers`
#   with the following content: `[3, 4, 5, 6, 7]`
# - Print the sum of the elements of `numbers`

numbers =[3,4,5,6,7]
Sum= 0
for number in numbers:
    Sum+= number
print(Sum)


#Method 2
#numbers =[3,4,5,6,7]
#print(sum(numbers))

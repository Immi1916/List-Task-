# - Create a variable named `numbers`
#   with the following content: `[1, 2, 3, 4, 5]`
# - Increment the third element
# - Print the third element
numbers =[1, 2, 3, 4, 5]
numbers[2]=numbers[2]+1
print(numbers)












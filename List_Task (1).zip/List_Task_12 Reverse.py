# - Create a variable named `numbers`
#   with the following content: `[3, 4, 5, 6, 7]`
# - Reverse the order of the elements of `numbers` programmatically
# - Print the elements of the reversed `numbers`:
#   [7, 6, 5, 4, 3]

#Method 1
Numbers = [3,4,5,6]
for i in reversed(Numbers):
    print(Numbers)


#Method 2
#Numbers =[3,4,5,6]
#Reversed_Number = Numbers[::-1]
#print(Reversed_Number)

#Method 3
#numbers =[3,4,5,6,7]
#numbers.reverse()
#print(numbers)




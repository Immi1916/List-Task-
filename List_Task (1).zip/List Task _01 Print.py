# - Create a variable named `numbers`
#   with the following content: `[4, 5, 6, 7]`
# - Print all the elements of `numbers`
numbers = [4,5,6,7]
print(numbers)





